function helloworld() {
    document.getElementById('foo').innerHTML = 'Hello JavaScript!';
}